/** mIRC-style color and bold formatting for public channel PRIVMSG. */

const RESET = '\x0f';
const BOLD = '\x02';

function color(fg: number, text: string): string {
  return `\x03${fg}${text}${RESET}`;
}

/** Strip channel status prefix from NAMES / PRIVMSG source. */
export function stripStatusPrefix(nick: string): string {
  return nick.replace(/^[~&@%+]+/, '').replace(/^\|/, '');
}

/** Colored "Nick:" before public !command replies; identical styling for every nick. */
export function chanReplyPrefix(nickNorm: string): string {
  return `${color(12, nickNorm)}:`;
}

export function styleChannelLine(text: string): string {
  if (text.length > 450) return text;
  const first = text[0];
  if (!first) return text;

  const leadColors: Record<string, number> = {
    '⚔': 8,
    '◇': 13,
    '✦': 12,
    '◆': 11,
    '⚡': 8,
    '★': 8,
    '⌛': 10,
    '▸': 10,
    '─': 6,
    '✧': 13,
    '▪': 12,
    '⟡': 14,
  };
  const fg = leadColors[first];
  if (fg === undefined) {
    if (text.startsWith('IdleRPG') || text.startsWith('The ledger') || text.startsWith('NetIRC')) {
      return `${color(11, text.slice(0, 1))}${color(10, text.slice(1))}`;
    }
    return text;
  }
  return `\x03${fg}${BOLD}${first}${RESET}\x03${fg}${text.slice(1)}${RESET}`;
}

export function styleAmbientBanter(text: string): string {
  return `${color(14, '»')}${RESET} ${color(11, text)}`;
}
